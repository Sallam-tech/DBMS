package airlinemamagementsystem;

import java.awt.*;
import java.awt.event.*;
import java.sql.ResultSet;
import javax.swing.*;
import java.sql.*;
public class lgn extends JFrame implements ActionListener {
    JTextField usernameField;
    JPasswordField passwordField;
    JLabel userLabel, passLabel;
    JButton resetBtn, submitBtn, closeBtn;

    public lgn() {
        super("Login Form");

        setLayout(null);
        getContentPane().setBackground(Color.WHITE);

        // Username label and text field
        userLabel = new JLabel("Username");
        userLabel.setBounds(50, 30, 100, 30);
        add(userLabel);

        usernameField = new JTextField();
        usernameField.setBounds(150, 30, 150, 30);
        add(usernameField);

        // Password label and password field
        passLabel = new JLabel("Password");
        passLabel.setBounds(50, 80, 100, 30);
        add(passLabel);

        passwordField = new JPasswordField();
        passwordField.setBounds(150, 80, 150, 30);
        add(passwordField);

        // Reset button
        resetBtn = new JButton("Reset");
        resetBtn.setBounds(30, 130, 100, 30);
        resetBtn.addActionListener(this);
        add(resetBtn);

        // Submit button
        submitBtn = new JButton("Submit");
        submitBtn.setBounds(140, 130, 100, 30);
        submitBtn.addActionListener(this);
        add(submitBtn);

        // Close button
        closeBtn = new JButton("Close");
        closeBtn.setBounds(250, 130, 100, 30);
        closeBtn.addActionListener(this);
        add(closeBtn);

        // Frame setup
        setSize(400, 250);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
        setLocationRelativeTo(null); // Center the window
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == resetBtn) {
            // Clear both fields
            usernameField.setText("");
            passwordField.setText("");
        } else if (e.getSource() == submitBtn) {

            // Handle login logic (for now, just show values)
            String username = usernameField.getText();
            String password = new String(passwordField.getPassword());
            try{
Conn c=new Conn();
String query="select*from login where username='"+username +"'and password='"+password+"'";
ResultSet rs = c.s.executeQuery(query);
if(rs.next()){
    new Home();

    setVisible(false);

}else{
    JOptionPane.showMessageDialog(null,"Invalid username or password");
    setVisible(false);
}
            }catch (Exception ex){
                ex.printStackTrace();
            }

            JOptionPane.showMessageDialog(this,
                    "Username: " + username + "\nPassword: " + password,
                    "Login Details",
                    JOptionPane.INFORMATION_MESSAGE
            );
        } else if (e.getSource() == closeBtn) {
            // Exit the application
            System.exit(0);
        }
    }

    public static void main(String[] args) {
        new lgn();
    }
}

