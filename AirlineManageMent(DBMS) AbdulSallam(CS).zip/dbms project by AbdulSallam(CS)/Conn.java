package airlinemamagementsystem;
import java.sql.*;

public class Conn {
    private Connection c;
    public Statement s;
    public Conn() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            c = DriverManager.getConnection("jdbc:mysql:///airlinesmanagementsystem", "root", "saniakhan");
            s = c.createStatement();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public Connection getConnection() {
        return c;
    }
}
