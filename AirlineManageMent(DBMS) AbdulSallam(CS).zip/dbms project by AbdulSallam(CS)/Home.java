package ${PACKAGE_NAME};

import java.awt.*;
import java.awt.event.*;
import java.sql.ResultSet;
import javax.swing.*;
import java.sql.*;

public class ${NAME} extends JFrame implements ActionListener {

    private JButton bookFlightButton;
    private JButton journeyDetailsButton;
    private JButton ticketCancelButton;
    private JMenuItem boardingPassMenuItem; // Changed to JMenuItem

    public ${NAME}() {
        super("Login Form");

        setLayout(null);
        ImageIcon icon = new ImageIcon(ClassLoader.getSystemResource("${PACKAGE_NAME}/icons/front.jpg"));
        JLabel label = new JLabel(icon);
        label.setBounds(0, 0, 1600, 800);
        add(label);
        JLabel heading = new JLabel("AIR PAKISTAN WELLCOMES YOU");
        heading.setBounds(500, 20, 1000, 40);
        heading.setForeground(Color.BLACK);
        heading.setFont(new Font("Times New Roman", Font.BOLD, 38));
        label.add(heading);
        JMenuBar menuBar = new JMenuBar();
        setJMenuBar(menuBar);
        JMenu details = new JMenu("Details");
        menuBar.add(details);
        JMenuItem FLIGHTDETAILS = new JMenuItem("Flight Details");
        FLIGHTDETAILS.addActionListener(this);
        details.add(FLIGHTDETAILS);
        JMenuItem customerdetails = new JMenuItem("add customer Details");
        customerdetails.addActionListener(this);
        details.add(customerdetails);

        JMenuItem bookflight = new JMenuItem("book flight");
        bookflight.addActionListener(this);
        details.add(bookflight);
        JMenuItem journeydetails = new JMenuItem("journey details");
        journeydetails.addActionListener(this);
        details.add(journeydetails);
        JMenuItem ticketcancellation = new JMenuItem("ticket cancellation");
        ticketcancellation.addActionListener(this);
        details.add(ticketcancellation);

        JMenu ticket = new JMenu(" ticket");
        menuBar.add(ticket);
        boardingPassMenuItem = new JMenuItem("boarding pass"); // Renamed and moved
        boardingPassMenuItem.addActionListener(this);
        ticket.add(boardingPassMenuItem);


        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setLocation(600, 250);

        setVisible(true);

    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String command = e.getActionCommand();
        if (command.equals("add customer Details")) {
            new AddCustomer();
        } else if (command.equals("Flight Details")) {
            new FlightInfo();
        } else if (command.equals("book flight")) {
            new BookFlight();
        } else if (command.equals("journey details")) {
            new JourneyDetails();
        } else if (command.equals("ticket cancellation")) {
            new Cancel();
        } else if (command.equals("boarding pass")) {
            new BoardingPass();
        }


    }

    public static void main(String[] args) {
        new ${NAME}();
    }
}
