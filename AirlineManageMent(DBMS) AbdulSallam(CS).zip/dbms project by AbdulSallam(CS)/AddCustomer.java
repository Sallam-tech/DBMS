package airlinemamagementsystem;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class AddCustomer extends JFrame implements ActionListener {
    JTextField NAME, NATIONALITY, CNICC, ADDRESSS, phonee;
    JRadioButton radioButton1, radioButton2;

    public AddCustomer() {
        getContentPane().setBackground(Color.WHITE);
        setLayout(null);

        JLabel heading = new JLabel("Add Customer");
        heading.setBounds(220, 20, 500, 35);
        heading.setFont(new Font("Arial", Font.BOLD, 32));
        heading.setForeground(Color.BLUE);
        add(heading);

        JLabel name = new JLabel("Name");
        name.setBounds(60, 80, 150, 25);
        name.setFont(new Font("Arial", Font.BOLD, 20));
        name.setForeground(Color.BLUE);
        add(name);

        NAME = new JTextField();
        NAME.setBounds(220, 80, 150, 25);
        add(NAME);

        JLabel nationalityLabel = new JLabel("Nationality");
        nationalityLabel.setBounds(60, 130, 150, 25);
        nationalityLabel.setFont(new Font("Arial", Font.BOLD, 20));
        nationalityLabel.setForeground(Color.BLUE);
        add(nationalityLabel);

        NATIONALITY = new JTextField();
        NATIONALITY.setBounds(220, 130, 150, 25);
        add(NATIONALITY);

        JLabel cnicLabel = new JLabel("CNIC");
        cnicLabel.setBounds(60, 180, 150, 25);
        cnicLabel.setFont(new Font("Arial", Font.BOLD, 20));
        cnicLabel.setForeground(Color.BLUE);
        add(cnicLabel);

        CNICC = new JTextField();
        CNICC.setBounds(220, 180, 150, 25);
        add(CNICC);

        JLabel addressLabel = new JLabel("Address");
        addressLabel.setBounds(60, 230, 150, 25);
        addressLabel.setFont(new Font("Arial", Font.BOLD, 20));
        addressLabel.setForeground(Color.BLUE);
        add(addressLabel);

        ADDRESSS = new JTextField();
        ADDRESSS.setBounds(220, 230, 150, 25);
        add(ADDRESSS);

        JLabel genderLabel = new JLabel("Gender");
        genderLabel.setBounds(60, 280, 150, 25);
        genderLabel.setFont(new Font("Arial", Font.BOLD, 20));
        genderLabel.setForeground(Color.BLUE);
        add(genderLabel);

        ButtonGroup bg = new ButtonGroup();
        radioButton1 = new JRadioButton("Male");
        radioButton1.setBackground(Color.WHITE);
        radioButton1.setBounds(220, 280, 70, 25);
        add(radioButton1);

        radioButton2 = new JRadioButton("Female");
        radioButton2.setBackground(Color.WHITE);
        radioButton2.setBounds(300, 280, 80, 25);
        add(radioButton2);

        bg.add(radioButton1);
        bg.add(radioButton2);

        JLabel phoneLabel = new JLabel("Phone");
        phoneLabel.setBounds(60, 330, 150, 25);
        phoneLabel.setFont(new Font("Arial", Font.BOLD, 20));
        phoneLabel.setForeground(Color.BLUE);
        add(phoneLabel);

        phonee = new JTextField();
        phonee.setBounds(220, 330, 150, 25);
        add(phonee);

        JButton SAVE = new JButton("Save");
        SAVE.setBackground(Color.BLACK);
        SAVE.setForeground(Color.WHITE);
        SAVE.setBounds(220, 380, 150, 30);
        SAVE.addActionListener(this);
        add(SAVE);

        ImageIcon image = new ImageIcon(ClassLoader.getSystemResource("airlinemamagementsystem/icons/emp.png"));
        JLabel imageLabel = new JLabel(image);
        imageLabel.setBounds(450, 80, 280, 400);
        add(imageLabel);

        // Frame settings
        setSize(800, 550);
        setLocation(300, 150);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        String name = NAME.getText();
        String nationality = NATIONALITY.getText();
        String cnic = CNICC.getText();
        String address = ADDRESSS.getText();
        String phone = phonee.getText();
        String gender = null;

        if (radioButton1.isSelected()) {
            gender = "Male";
        } else if (radioButton2.isSelected()) {
            gender = "Female";
        }

        try {
            Conn conn = new Conn();
            String query = "insert into passenger values('" + name + "','" + nationality + "','" + cnic + "','" + phone + "','" + gender + "','" + address + "')";
            conn.s.executeUpdate(query);
            JOptionPane.showMessageDialog(null, "Customer Added Successfully!");
            setVisible(false);
        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

    public static void main(String[] args) {
        new AddCustomer();
    }
}

