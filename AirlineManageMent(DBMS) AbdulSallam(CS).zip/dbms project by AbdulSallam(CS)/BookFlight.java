package airlinemamagementsystem;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import com.toedter.calendar.JDateChooser;
import java.util.*;

public class BookFlight extends JFrame implements ActionListener {
    JTextField CNICC;
    JLabel NAME, ADDRESSS, NATIONALITY, flightname, flightcode, GENDER;
    JDateChooser flightdate;
    JButton bookFlightButton, fetchButton, flight;
    Choice Source, Destination;
    Conn c; // Added a Conn object

    public BookFlight() {
        getContentPane().setBackground(Color.WHITE);
        setLayout(null);

        JLabel heading = new JLabel("Book Flight");
        heading.setBounds(420, 20, 500, 35);
        heading.setFont(new Font("Arial", Font.BOLD, 32));
        heading.setForeground(Color.BLUE);
        add(heading);

        JLabel cnicLabel = new JLabel("CNIC");
        cnicLabel.setBounds(60, 80, 150, 25);
        cnicLabel.setFont(new Font("Arial", Font.BOLD, 20));
        cnicLabel.setForeground(Color.BLUE);
        add(cnicLabel);

        CNICC = new JTextField();
        CNICC.setBounds(220, 80, 150, 25);
        add(CNICC);

        fetchButton = new JButton("Fetch user");
        fetchButton.setBackground(Color.BLACK);
        fetchButton.setForeground(Color.WHITE);
        fetchButton.setBounds(380, 80, 120, 25);
        fetchButton.addActionListener(this);
        add(fetchButton);

        JLabel name = new JLabel("Name");
        name.setBounds(60, 130, 150, 25);
        name.setFont(new Font("Arial", Font.BOLD, 20));
        name.setForeground(Color.BLUE);
        add(name);

        NAME = new JLabel();
        NAME.setBounds(220, 130, 200, 25);
        add(NAME);

        JLabel nationalityLabel = new JLabel("Nationality");
        nationalityLabel.setBounds(60, 180, 150, 25);
        nationalityLabel.setFont(new Font("Arial", Font.BOLD, 20));
        nationalityLabel.setForeground(Color.BLUE);
        add(nationalityLabel);

        NATIONALITY = new JLabel();
        NATIONALITY.setBounds(220, 180, 200, 25);
        add(NATIONALITY);

        JLabel addressLabel = new JLabel("Address");
        addressLabel.setBounds(60, 230, 150, 25);
        addressLabel.setFont(new Font("Arial", Font.BOLD, 20));
        addressLabel.setForeground(Color.BLUE);
        add(addressLabel);

        ADDRESSS = new JLabel();
        ADDRESSS.setBounds(220, 230, 300, 25);
        add(ADDRESSS);

        JLabel genderLabel = new JLabel("Gender");
        genderLabel.setBounds(60, 280, 150, 25);
        genderLabel.setFont(new Font("Arial", Font.BOLD, 20));
        genderLabel.setForeground(Color.BLUE);
        add(genderLabel);

        GENDER = new JLabel();
        GENDER.setBounds(220, 280, 150, 25);
        add(GENDER);

        JLabel LabelSOURCE = new JLabel("Source");
        LabelSOURCE.setBounds(60, 330, 150, 25);
        LabelSOURCE.setFont(new Font("Arial", Font.BOLD, 20));
        LabelSOURCE.setForeground(Color.BLUE);
        add(LabelSOURCE);

        Source = new Choice();
        Source.setBounds(220, 330, 150, 25);
        add(Source);

        JLabel LBLDEST = new JLabel("Destination");
        LBLDEST.setBounds(60, 380, 150, 25);
        LBLDEST.setFont(new Font("Arial", Font.BOLD, 20));
        LBLDEST.setForeground(Color.BLUE);
        add(LBLDEST);

        Destination = new Choice();
        Destination.setBounds(220, 380, 150, 25);
        add(Destination);

        flight = new JButton("Fetch Flights");
        flight.setBackground(Color.BLACK);
        flight.setForeground(Color.WHITE);
        flight.setBounds(380, 380, 120, 25);
        flight.addActionListener(this);
        add(flight);

        JLabel fname = new JLabel("Flight Name");
        fname.setBounds(60, 430, 150, 25);
        fname.setFont(new Font("Arial", Font.BOLD, 20));
        fname.setForeground(Color.BLUE);
        add(fname);

        flightname = new JLabel();
        flightname.setBounds(220, 430, 200, 25);
        add(flightname);

        JLabel fcode = new JLabel("Flight Code");
        fcode.setBounds(60, 480, 150, 25);
        fcode.setFont(new Font("Arial", Font.BOLD, 20));
        fcode.setForeground(Color.BLUE);
        add(fcode);

        flightcode = new JLabel();
        flightcode.setBounds(220, 480, 200, 25);
        add(flightcode);

        JLabel fdate = new JLabel("Date of Travel");
        fdate.setBounds(60, 530, 150, 25);
        fdate.setFont(new Font("Arial", Font.BOLD, 20));
        fdate.setForeground(Color.BLUE);
        add(fdate);

        flightdate = new JDateChooser();
        flightdate.setBounds(220, 530, 150, 25);
        add(flightdate);

        bookFlightButton = new JButton("Book Flight");
        bookFlightButton.setBackground(Color.BLACK);
        bookFlightButton.setForeground(Color.WHITE);
        bookFlightButton.setBounds(220, 580, 150, 30);
        bookFlightButton.addActionListener(this);
        add(bookFlightButton);

        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("airlinemamagementsystem/icons/details.jpg"));
        Image i2 = i1.getImage().getScaledInstance(450, 320, Image.SCALE_DEFAULT);
        ImageIcon image = new ImageIcon(i2);
        JLabel imageLabel = new JLabel(image);
        imageLabel.setBounds(550, 80, 500, 410);
        add(imageLabel);

        setSize(1100, 700);
        setLocation(200, 50);
        setVisible(true);

        try {
            c = new Conn();
            String query = "SELECT DISTINCT source, destination FROM flight";
            ResultSet rs = c.s.executeQuery(query);
            while (rs.next()) {
                Source.add(rs.getString("source"));
                Destination.add(rs.getString("destination"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == fetchButton) {
            String cnic = CNICC.getText();
            try {
                //Conn conn = new Conn(); // Use the class member 'c'
                String query = "SELECT * FROM passenger WHERE cnic = '" + cnic + "'";
                ResultSet rs = c.s.executeQuery(query);
                if (rs.next()) {
                    NAME.setText(rs.getString("name"));
                    NATIONALITY.setText(rs.getString("nationality"));
                    ADDRESSS.setText(rs.getString("address"));
                    GENDER.setText(rs.getString("gender"));
                } else {
                    JOptionPane.showMessageDialog(null, "User does not exist");
                }
            } catch (Exception e2) {
                e2.printStackTrace();
            }
        } else if (e.getSource() == flight) {
            String src = Source.getSelectedItem().toLowerCase();
            String dest = Destination.getSelectedItem().toLowerCase();

            try {
                //Conn conn = new Conn();  // Use the class member 'c'
                String query = "SELECT f_name, f_code FROM flight WHERE LOWER(source) = '" + src + "' AND LOWER(destination) = '" + dest + "'";
                ResultSet rs = c.s.executeQuery(query);
                if (rs.next()) {
                    flightname.setText(rs.getString("f_name"));
                    flightcode.setText(rs.getString("f_code"));
                } else {
                    flightname.setText("");
                    flightcode.setText("");
                    JOptionPane.showMessageDialog(null, "No flight found for selected route.");
                }
            } catch (Exception e2) {
                e2.printStackTrace();
            }

        } else if (e.getSource() == bookFlightButton) {
            try {
                Random random = new Random();
                String pnr = "PNR-" + random.nextInt(1000000);
                String ticket = "TIC-" + random.nextInt(10000);
                String cinic = CNICC.getText();
                String name = NAME.getText();
                String nationality = NATIONALITY.getText();
                String src = Source.getSelectedItem();
                String des = Destination.getSelectedItem();
                String flightnamee = flightname.getText();
                String flightcodee = flightcode.getText();
                String ddate = ((JTextField) flightdate.getDateEditor().getUiComponent()).getText();

                if (cinic.equals("") || name.equals("") || nationality.equals("")|| src.equals("") || des.equals("") || flightnamee.equals("") || flightcodee.equals("") || ddate.equals("")) {
                    JOptionPane.showMessageDialog(null, "Please fill all details before booking.");
                    return;
                }

                //Conn conn = new Conn();  // Use the class member 'c'
                String query = "INSERT INTO reservation VALUES('" + pnr + "', '" + ticket + "', '" + cinic + "', '" + name + "', '" + nationality + "', '" + src + "', '" + des + "', '" + flightnamee + "', '" + flightcodee + "', '" + ddate + "')";
                c.s.executeUpdate(query);

                JOptionPane.showMessageDialog(null, "Ticket Booked Successfully!\nPNR: " + pnr + "\nTicket No: " + ticket);
            } catch (Exception e3) {
                e3.printStackTrace();
            }
        }
    }

    public static void main(String[] args) {
        new BookFlight();
    }
}
