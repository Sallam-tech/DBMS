package airlinemamagementsystem;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class BoardingPass extends JFrame implements ActionListener {

    private JTextField tfpnr;
    private JLabel tfname, tfnationality, lblsrc, lbldest, labelfname, labelfcode, labeldate;
    private JButton fetchButton; // Removed Enter button
    private Conn c;
    private JLabel lblimage;

    public BoardingPass() {
        // JFrame setup
        setTitle("Boarding Pass");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        getContentPane().setBackground(Color.WHITE);
        setLayout(null);
        setSize(800, 650);
        setLocation(300, 100);
        setVisible(true);

        // Heading Label
        JLabel heading = new JLabel("AIR PAKISTAN");
        heading.setFont(new Font("Tahoma", Font.BOLD, 24));
        heading.setBounds(300, 20, 200, 30);
        heading.setForeground(Color.BLUE);
        add(heading);

        // Sub-heading
        JLabel subheading = new JLabel("Boarding Pass");
        subheading.setFont(new Font("Tahoma", Font.BOLD, 20));
        subheading.setBounds(320, 60, 200, 30);
        add(subheading);


        // PNR DETAILS Label
        JLabel pnrLabel = new JLabel("PNR DETAILS");
        pnrLabel.setBounds(50, 160, 150, 25);
        pnrLabel.setFont(new Font("Tahoma", Font.BOLD, 20));
        add(pnrLabel);

        // PNR Number Label and TextField
        JLabel lblpnr = new JLabel("PNR No:");
        lblpnr.setBounds(50, 200, 100, 25);
        add(lblpnr);
        tfpnr = new JTextField();
        tfpnr.setBounds(150, 200, 200, 25);
        add(tfpnr);

        // Show Details Button
        fetchButton = new JButton("Show Details");
        fetchButton.setBounds(400, 200, 120, 25); // Adjusted position
        fetchButton.setBackground(Color.BLACK);
        fetchButton.setForeground(Color.WHITE);
        fetchButton.addActionListener(this);
        add(fetchButton);

        // Name Label
        JLabel lblnameLabel = new JLabel("Name");
        lblnameLabel.setBounds(50, 250, 150, 25);
        lblnameLabel.setFont(new Font("Tahoma", Font.BOLD, 20));
        add(lblnameLabel);
        tfname = new JLabel();
        tfname.setBounds(250, 250, 200, 25);
        add(tfname);

        // Nationality Label
        JLabel lblnationalityLabel = new JLabel("Nationality");
        lblnationalityLabel.setBounds(50, 300, 150, 25);
        lblnationalityLabel.setFont(new Font("Tahoma", Font.BOLD, 20));
        add(lblnationalityLabel);
        tfnationality = new JLabel();
        tfnationality.setBounds(250, 300, 200, 25);
        add(tfnationality);

        // Source Label
        JLabel lblsrcLabel = new JLabel("Source");
        lblsrcLabel.setBounds(50, 350, 150, 25);
        lblsrcLabel.setFont(new Font("Tahoma", Font.BOLD, 20));
        add(lblsrcLabel);
        lblsrc = new JLabel();
        lblsrc.setBounds(250, 350, 200, 25);
        add(lblsrc);

        // Destination Label
        JLabel lbldestLabel = new JLabel("Destination");
        lbldestLabel.setBounds(50, 400, 150, 25);
        lbldestLabel.setFont(new Font("Tahoma", Font.BOLD, 20));
        add(lbldestLabel);
        lbldest = new JLabel();
        lbldest.setBounds(250, 400, 200, 25);
        add(lbldest);

        // Flight Name Label
        JLabel lblfnameLabel = new JLabel("Flight Name");
        lblfnameLabel.setBounds(50, 450, 150, 25);
        lblfnameLabel.setFont(new Font("Tahoma", Font.BOLD, 20));
        add(lblfnameLabel);
        labelfname = new JLabel();
        labelfname.setBounds(250, 450, 200, 25);
        add(labelfname);

        // Flight Code Label
        JLabel lblfcodeLabel = new JLabel("Flight Code");
        lblfcodeLabel.setBounds(50, 500, 150, 25);
        lblfcodeLabel.setFont(new Font("Tahoma", Font.BOLD, 20));
        add(lblfcodeLabel);
        labelfcode = new JLabel();
        labelfcode.setBounds(250, 500, 200, 25);
        add(labelfcode);

        // Date Label
        JLabel lbldateLabel = new JLabel("Date");
        lbldateLabel.setBounds(50, 550, 150, 25);
        lbldateLabel.setFont(new Font("Tahoma", Font.BOLD, 20));
        add(lbldateLabel);
        labeldate = new JLabel();
        labeldate.setBounds(250, 550, 200, 25);
        add(labeldate);

        try {
            c = new Conn();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error connecting to the database: " + e.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }

    }

    @Override
    public void actionPerformed(ActionEvent ae) {
        try {
            if (ae.getSource() == fetchButton) { // Removed Enter button condition
                String pnr = tfpnr.getText();
                String query = "select * from reservation where PNR = '" + pnr + "'";
                Statement s = c.getConnection().createStatement();
                ResultSet rs = s.executeQuery(query);

                if (rs.next()) {
                    tfname.setText(rs.getString("name"));
                    tfnationality.setText(rs.getString("nationality"));
                    lblsrc.setText(rs.getString("src"));
                    lbldest.setText(rs.getString("des"));
                    labelfname.setText(rs.getString("flightname"));
                    labelfcode.setText(rs.getString("flightcode"));
                    labeldate.setText(rs.getString("ddate"));
                } else {
                    JOptionPane.showMessageDialog(null, "Please enter correct PNR");
                    tfname.setText("");
                    tfnationality.setText("");
                    lblsrc.setText("");
                    lbldest.setText("");
                    labelfname.setText("");
                    labelfcode.setText("");
                    labeldate.setText("");
                }
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Unexpected Error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        new BoardingPass();
    }
}
