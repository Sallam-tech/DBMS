package airlinemamagementsystem;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.util.Random;

public class Cancel extends JFrame implements ActionListener {

    private JTextField tfpnr;
    private JLabel tfname, lblfcode, lbldateoftravel, cancellationnoLabel, cancelNoValue;
    private JButton fetchButton, flight;
    private Conn c;

    public Cancel() {
        // JFrame setup
        setTitle("Ticket Cancellation");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        getContentPane().setBackground(Color.WHITE);
        setLayout(null);
        setSize(800, 600);
        setLocation(300, 100);
        setVisible(true);

        // Heading Label
        JLabel heading = new JLabel("CANCELLATION");
        heading.setFont(new Font("Tahoma", Font.BOLD, 24));
        heading.setBounds(250, 20, 300, 30);
        heading.setForeground(Color.BLUE);
        add(heading);

        // ImageIcon and JLabel for background
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("airlinemamagementsystem/icons/cancel.jpg"));
        Image i2 = i1.getImage().getScaledInstance(300, 300, Image.SCALE_DEFAULT); // Reduced size
        ImageIcon i3 = new ImageIcon(i2);
        JLabel imageLabel = new JLabel(i3);
        imageLabel.setBounds(450, 150, 300, 300); // Moved to the right side
        add(imageLabel);

        // PNR Number Label and TextField
        JLabel lblpnr = new JLabel("PNR Number");
        lblpnr.setBounds(50, 100, 150, 25);
        lblpnr.setFont(new Font("Tahoma", Font.BOLD, 20));
        add(lblpnr);
        tfpnr = new JTextField();
        tfpnr.setBounds(220, 100, 200, 25);
        add(tfpnr);

        // Show Details Button
        fetchButton = new JButton("Show Details");
        fetchButton.setBounds(450, 100, 120, 25);
        fetchButton.setBackground(Color.BLACK);
        fetchButton.setForeground(Color.WHITE);
        fetchButton.addActionListener(this);
        add(fetchButton);

        // Name Label
        JLabel lblnameLabel = new JLabel("Name");
        lblnameLabel.setBounds(50, 150, 150, 25);
        lblnameLabel.setFont(new Font("Tahoma", Font.BOLD, 20));
        add(lblnameLabel);
        tfname = new JLabel();
        tfname.setBounds(220, 150, 200, 25);
        add(tfname);

        // Cancellation No Label
        cancellationnoLabel = new JLabel("Cancellation No");
        cancellationnoLabel.setBounds(50, 200, 150, 25);
        cancellationnoLabel.setFont(new Font("Tahoma", Font.BOLD, 20));
        add(cancellationnoLabel);
        cancelNoValue = new JLabel();
        cancelNoValue.setBounds(220, 200, 200, 25);
        add(cancelNoValue);

        // Flight Code Label
        JLabel lblfcodeLabel = new JLabel("Flight Code");
        lblfcodeLabel.setBounds(50, 250, 150, 25);
        lblfcodeLabel.setFont(new Font("Tahoma", Font.BOLD, 20));
        add(lblfcodeLabel);
        lblfcode = new JLabel();
        lblfcode.setBounds(220, 250, 200, 25);
        add(lblfcode);

        // Date of Travel Label
        JLabel lbldateoftravelLabel = new JLabel("Date of Travel");
        lbldateoftravelLabel.setBounds(50, 300, 150, 25);
        lbldateoftravelLabel.setFont(new Font("Tahoma", Font.BOLD, 20));
        add(lbldateoftravelLabel);
        lbldateoftravel = new JLabel();
        lbldateoftravel.setBounds(220, 300, 200, 25);
        add(lbldateoftravel);

        // Cancel Button
        flight = new JButton("Cancel Ticket");
        flight.setBounds(270, 400, 150, 30);
        flight.setBackground(Color.BLACK);
        flight.setForeground(Color.WHITE);
        flight.addActionListener(this);
        add(flight);

        try {
            c = new Conn();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error connecting to the database: " + e.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
            // Consider returning here
        }

    }

    @Override
    public void actionPerformed(ActionEvent ae) {
        try {
            if (ae.getSource() == fetchButton) {
                String pnr = tfpnr.getText();
                String query = "select * from reservation where PNR = '" + pnr + "'";
                Statement s = c.getConnection().createStatement();
                ResultSet rs = s.executeQuery(query);

                if (rs.next()) {
                    tfname.setText(rs.getString("name"));
                    lblfcode.setText(rs.getString("flightcode"));
                    lbldateoftravel.setText(rs.getString("ddate"));
                } else {
                    JOptionPane.showMessageDialog(null, "Please enter correct PNR");
                    tfname.setText("");
                    lblfcode.setText("");
                    lbldateoftravel.setText("");
                }
            } else if (ae.getSource() == flight) {
                String pnr = tfpnr.getText();
                String name = tfname.getText();
                String fcode = lblfcode.getText();
                String date = lbldateoftravel.getText();
                Random random = new Random();
                String cancelno = "829402";
                cancelNoValue.setText(cancelno);

                if (pnr.equals("") || name.equals("") || fcode.equals("") || date.equals("")) {
                    JOptionPane.showMessageDialog(null, "Please Show Details First.");
                    return;
                }

                String query = "insert into cancel values('" + pnr + "', '" + cancelno + "', '" + name + "', '" + fcode + "', '" + date + "')";
                String query1 = "delete from reservation where PNR = '" + pnr + "'";

                Statement s = c.getConnection().createStatement();
                s.executeUpdate(query);
                s.executeUpdate(query1);

                JOptionPane.showMessageDialog(null, "Ticket Cancelled\n" + "Your Cancellation No is " + cancelno);
                setVisible(false);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Unexpected Error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        new Cancel();
    }
}
