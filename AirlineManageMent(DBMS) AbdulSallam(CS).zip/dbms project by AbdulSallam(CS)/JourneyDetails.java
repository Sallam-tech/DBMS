package airlinemamagementsystem;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import net.proteanit.sql.DbUtils;

public class JourneyDetails extends JFrame implements ActionListener {

    private JTextField pnrTextField;
    private JTable table;
    private JButton showDetailsButton;
    private Conn c;  // Class level declaration

    public JourneyDetails() {
        // JFrame setup
        setTitle("PNR Details");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        getContentPane().setBackground(Color.WHITE);
        setLayout(null);
        setSize(800, 600);
        setLocation(300, 100);
        setVisible(true);

        // Heading Label
        JLabel headingLabel = new JLabel("PNR Details");
        headingLabel.setFont(new Font("Tahoma", Font.BOLD, 24));
        headingLabel.setBounds(280, 20, 300, 30);
        headingLabel.setForeground(Color.BLUE);
        add(headingLabel);

        // PNR Label and TextField
        JLabel pnrLabel = new JLabel("PNR No:");
        pnrLabel.setBounds(50, 80, 100, 20);
        add(pnrLabel);
        pnrTextField = new JTextField();
        pnrTextField.setBounds(150, 80, 200, 25);
        add(pnrTextField);

        // Show Details Button
        showDetailsButton = new JButton("Show Details");
        showDetailsButton.setBounds(400, 80, 120, 25);
        showDetailsButton.setBackground(Color.BLACK);
        showDetailsButton.setForeground(Color.WHITE);
        showDetailsButton.addActionListener(this);
        add(showDetailsButton);

        // Table to display results
        table = new JTable();
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBounds(50, 150, 700, 400);
        add(scrollPane);

        try {
            c = new Conn();  // Initialize in constructor
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error connecting to the database: " + e.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
            // Consider returning or exiting the constructor if the connection fails.
        }
    }

    @Override
    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == showDetailsButton) {
            String pnr = pnrTextField.getText();
            try {
                String query = "select * from reservation where PNR = '" + pnr + "'";
                Statement s = c.getConnection().createStatement();
                ResultSet rs = s.executeQuery(query);

                if (!rs.isBeforeFirst()) {
                    JOptionPane.showMessageDialog(null, "No Information Found");
                } else {
                    table.setModel(DbUtils.resultSetToTableModel(rs));
                }

            } catch (SQLException e) {
                JOptionPane.showMessageDialog(this, "Error executing query: " + e.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
                e.printStackTrace(); // VERY IMPORTANT: Print the stack trace to diagnose the error.
            }        }
    }

    public static void main(String[] args) {
        new JourneyDetails();
    }
}
